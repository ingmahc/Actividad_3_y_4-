/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ecommerce.ecommerce.service;

import com.ecommerce.ecommerce.model.User;
import com.ecommerce.ecommerce.repository.UserRepository;
import com.ecommerce.ecommerce.security.JwtUtils;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 *
 * @author ingma
 */

@Service
public class AuthService {
    
    @Autowired
    private UserRepository userRepository;
    
    
    @Autowired
    private PasswordEncoder paswordEncoder;
    
    @Autowired
    private JwtUtils jwtUtils;
    
    //registrar usuario
    public String registerUser(String name,String email,String phone,String password,String address){
        //verificar si el correo ya esta registrado
        if (userRepository.existsByEmail(email)){
            throw new IllegalArgumentException("el correo ya esta registrado...");
            
        }
        
        //crear usuario
        User newUser = new User();
        newUser.setName(name);
        newUser.setEmail(email);
        newUser.setPhone(phone);
        newUser.setPassword(paswordEncoder.encode(password));
        newUser.setAddress(address);
        newUser.setRole("USER");//asignar role predeterminado
        
        //guardar ususario
        userRepository.save(newUser);
        return "Usuario registrado con exito";
              
        
    }
    
    //autenticar usuario
    public String authenticateUser(String email, String password){
        
        Optional<User> userOptional = userRepository.findByEmail(email);
        if (!userOptional.isPresent()){
            throw new IllegalArgumentException("Credenciales incorrectar");
        }
        
        User user = userOptional.get();
        System.out.println("usuario encontrado"+user.getName());
        //verificar la contraseña
        if(!paswordEncoder.matches(password, user.getPassword())){
            throw new IllegalArgumentException("Credenciales incorrectar");
        }
        //generar el token JWT
        try{
            System.out.println("Generando token JWT...");
            String token = jwtUtils.generateToken(user);
            System.out.println("Token generado"+token);
            return token;
        }catch (Exception e){
            System.out.println("Error al generar el token: "+e.getMessage());
            throw new RuntimeException("Error interno al generar el token");
        }
        
        
        
    }
    
}
