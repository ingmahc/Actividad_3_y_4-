package com.ecommerce.ecommerce;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @author ingma
 */
@SpringBootApplication
public class BackenddApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(BackenddApplication.class, args);
    }
}

